<?php

require_once dirname(__DIR__) . "/repository/WalletRepository.php";
require_once dirname(__DIR__) . "/entity/WalletEntity.php";

final class WalletService
{
    private function __construct()
    {
    }

    public static function createWallet(WalletEntity $wallet): int
    {
        return WalletRepository::insert($wallet);
    }

    public static function depot(WalletEntity $wallet, float $montant): bool
    {
        if ($montant <= 0) {
            return false;
        }

        return WalletRepository::update($wallet, $montant);
    }

    public static function retrait(WalletEntity $wallet, float $montant): bool
    {
        if ($montant <= 0) {
            return false;
        }

        return WalletRepository::update2($wallet, $montant);
    }
}