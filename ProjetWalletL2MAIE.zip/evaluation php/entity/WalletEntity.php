<?php 
require_once dirname(__DIR__)."/entity/TransationEntity.php";
class walletEntity{
    private static int $counter=0;
    private int $id;
    private float $solde;
    private string $code;
    private string $nom; 
    private string $prenom; 
    private string $telephone;
    private array $transations;
    public function __construct( string $nom,  string $prenom, string $telephone,string $code,int|null $id=null)
    {
            if ($id === null) {
                ClientEntity::$counter++;
                $this->id = ClientEntity::$counter;
            } else {
                $this->id = $id;
            }
        $this->id = $id;
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->telephone = $telephone;
        $this->code = $code;
        $this->solde = "0";
        $this->transations = [];

    }
    public function getId(): int
    {
        return $this->id;
    }
    public function getNom(): string
    {
        return $this->nom;
    }
    public function getPrenom(): string
    {
        return $this->prenom;
    }public function getTelephone(): string
    {
        return $this->telephone;
    }
    public function getCode(): string
    {
        return $this->code;
    }
    public function getSolde(): string
    {
        return $this->solde;
    }
    public function getTransations(): array
    {
        return $this->transations;
    }
}