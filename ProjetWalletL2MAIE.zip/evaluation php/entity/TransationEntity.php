<?php 
class TransationEntity{
    private static int $counter=0;
    private int $id;
    private string $code;
    private float $montant; 
    private string $type; 
    private string $date;
    private string $heure; 
    
    public function __construct( string $code,  string $montant, string $type,string $date,string $heure,int|null $id=null)
    {
            if ($id === null) {
                ClientEntity::$counter++;
                $this->id = ClientEntity::$counter;
            } else {
                $this->id = $id;
            }
        $this->id = $id;
        $this->code = $code;
        $this->montant = $montant;
        $this->type = $type;
        $this->date = $date;  
        $this->heure = $heure;  
    }
    public function getId(): int
    {
        return $this->id;
    }
    public function getCode(): string
    {
        return $this->code;
    }
    public function getMontant(): string
    {
        return $this->montant;
    }
    public function getType(): string
    {
        return $this->type;
    }
    public function getDate(): string
    {
        return $this->date;
    }
    public function getHeure(): string
    {
        return $this->heure;
    }
}
