<?php 
require_once dirname(__DIR__)."/entity/walletEntity.php";
final class WalletRepository{

    const TABLENAME="wallets";
    private function __construct()
    {
   
    }

    public static function insert(WalletEntity $wallet): int
    {
        $nom=$wallet->getNom();
        $prenom=$wallet->getPrenom();
        $telephone=$wallet->getTelephone();
        $code=$wallet->getCode();
        $solde=$wallet->getSolde();
        $sql="INSERT INTO " . self::TABLENAME . " (nom, prenom, code, solde, telephone) VALUES ('$nom', '$prenom', '$code', '$solde', '$telephone')";
            $sgbd="mysql";
            $host = "127.0.0.1";
            $dbname = "gestion_stock_cdsd_mae_2026";
            $username = "root";
            $password = "root";
            $port = "8889";
         try {
            $pdo = new PDO("$sgbd:host=$host;dbname=$dbname;port=$port", $username, $password);
             $nbreLigneAffectes = $pdo->exec($sql);
            return $nbreLigneAffectes;
         } catch (PDOException $e) {
            echo "Erreur de connexion à la base de données: " . $e->getMessage();
            return 0;
         }
        
    }
    public static function update(WalletEntity $wallet, float $montant): bool
    {
        $code = $wallet->getCode();

    $sgbd = "mysql";
    $host = "127.0.0.1";
    $dbname = "gestion_stock_cdsd_mae_2026";
    $username = "root";
    $password = "root";
    $port = "8889";

    try {
        $pdo = new PDO(
            "$sgbd:host=$host;dbname=$dbname;port=$port",
            $username,
            $password
        );

        $sql = "UPDATE wallets
                SET solde = solde + $montant
                WHERE code = $code";

        $stmt = $pdo->query($sql);

        return $stmt->exec([$montant, $code]);

    } catch (PDOException $e) {
        echo "Erreur de connexion à la base de données: " . $e->getMessage();
        return false;
    }
}
public static function update2(WalletEntity $wallet, float $montant): bool
{
    $code = $wallet->getCode();

    $sgbd = "mysql";
    $host = "127.0.0.1";
    $dbname = "gestion_stock_cdsd_mae_2026";
    $username = "root";
    $password = "root";
    $port = "8889";

    try {
        $pdo = new PDO(
            "$sgbd:host=$host;dbname=$dbname;port=$port",
            $username,
            $password
        );
        $sql = "SELECT solde FROM wallets WHERE code = $code";
        $stmt = $pdo->query($sql);
        $stmt->execute();

        $walletData = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$walletData) {
            return false; 
        }
        $soldeActuel = $walletData['solde'];

        if ($soldeActuel < $montant) {
            return false; 
        }
        $sql = "UPDATE wallets
                SET solde = solde - $montant
                WHERE code = $code";

        $stmt = $pdo->query($sql);

        return $stmt->execute([$montant, $code]);

    } catch (PDOException $e) {
        echo "Erreur de connexion à la base de données: " . $e->getMessage();
        return false;
    }
}
    }
