<?php

require_once dirname(__DIR__)."/service/WalletService.php";
require_once dirname(__DIR__)."/entity/WalletEntity.php";

final class WalletController{

    private function __construct()
    {
        throw new Exception("Not implemented");
    }

    // Création d'un wallet
    public static function submitCreateForm(){

        $nom = trim($_POST['nom'] ?? '');
        $prenom = trim($_POST['prenom'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $code = trim($_POST['code'] ?? '');
        $solde = trim($_POST['solde'] ?? 0);

        $wallet = new WalletEntity();

        $wallet->setNom($nom);
        $wallet->setPrenom($prenom);
        $wallet->setTelephone($telephone);
        $wallet->setCode($code);
        $wallet->setSolde($solde);

        WalletService::createWallet($wallet);
    }

    public static function submitDepotForm(){

        $code = trim($_POST['code'] ?? '');
        $montant = trim($_POST['montant'] ?? 0);

        $wallet = new WalletEntity();
        $wallet->setCode($code);

        WalletService::depot($wallet, $montant);
    }

    public static function submitRetraitForm(){

        $code = trim($_POST['code'] ?? '');
        $montant = trim($_POST['montant'] ?? 0);

        $wallet = new WalletEntity();
        $wallet->setCode($code);

        WalletService::retrait($wallet, $montant);
    }

    public static function loadCreateForm(){
        require_once(dirname(dirname(__DIR__))."/views/view.php");
    }
    public static function loadDepotForm(){
        require_once(dirname(dirname(__DIR__))."/views/view.php");
    }
    public static function loadRetraitForm(){
        require_once(dirname(dirname(__DIR__))."/views/view.php");
    }
}