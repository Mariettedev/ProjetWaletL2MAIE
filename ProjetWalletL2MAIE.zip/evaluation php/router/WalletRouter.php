<?php

require_once __DIR__."/controller/WalletController.php";

final class WalletRouter{

    public static function run(): void
    {
        $uri = $_SERVER['REQUEST_URI'];
        $uriAction = explode("?", $uri)[0];

        switch ($uriAction) {

            case '/':
            case '/wallet-form':
                WalletController::loadCreateForm();
                break;

            case '/wallet-create':
                WalletController::submitCreateForm();
                break;

            case '/wallet-depot-form':
                WalletController::loadDepotForm();
                break;

            case '/wallet-depot':
                WalletController::submitDepotForm();
                break;

            case '/wallet-retrait-form':
                WalletController::loadRetraitForm();
                break;

            case '/wallet-retrait':
                WalletController::submitRetraitForm();
                break;

            default:
                break;
        }
    }
}